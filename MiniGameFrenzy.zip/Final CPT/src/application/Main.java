/* ICS4U1 CPT: MINIGAME FRENZY 2.0
 * Gunin Walia, Kajhanan Sabesan
 * Mr.Conway
 * 
 * Program Description: The program is a second iteration of the minigame frenzy
 *  that we made last year. With this program, there are two games: Whack a Mole 
 *  and Hit or Miss. With Whack a mole, there are 9 holes where several moles can
 *  spawn at a time at random locations. Your job as the player is to bonk as many
 *  as you can within the time limit. Unlike regular Whack a mole, there is a super
 *  mole that if you click them, there is a chance that you can get a good or bad 
 *  perk. You can get things such as extra points or freeze time, which allows you 
 *  to keep bonking to your hearts pleasure, but it can also include things such as 
 *  losing time and points, which has the player on edge about whether or not to bonk
 *  the super mole, which adds that twist to the regular whack a mole game. With the 
 *  game hit or miss, there is a moving platform at the top of the screen that moves 
 *  from side to side. You are able to shoot projectiles upwards from a pipe located at the 
 *  bottom of the screen. Your job as the player is to hit the platform as much as you can 
 *  within the time limit. With this game, you have a limited amount of ammunition which will
 *  end the game as soon as you use up all of it. If you miss the platform, you lose points 
 *  but if you hit the platform, you gain points. If your score ends up below zero, the
 *  game ends. When the hit or miss game ends, users will have a chance to view all previous 
 *  scores and they have been sorted in descending order. The program will then end.
 *  
 * Program Details: Our program uses JavaFX components throughout the code, an example 
 *  would be buttons and images. Images are used for aesthetics throughout a program and 
 *  for the actual animation. Buttons are used to help the user engage with the main page.
 *  Alerts are constantly utilized throughout the program. Before the game starts and when
 *  the game ends, an alert is displayed to the user containing important information. The
 *  grid pane layout is utilized for the main page. It helps organize the background image
 *  and the main buttons. The use of arrays is there in the whack a mole game, as the 
 *  moles are stored in a 2D array. Sorting/Searching methods are used to display the high
 *  scores to the user in ascending order. Highscores are only displayed if the user wishes
 *  to see them after the hit or miss game. Object-oriented programming(classes) is used for
 *  both games. An example would be the wall class. This class is utilized by the hit 
 *  or miss game and enables the barrier to move. With inheritance, in the whack a mole game, 
 *  there are 2 classes which are the mole and supermole classes. These two classes are very similar 
 *  and as such, the supermole class can do everything that the mole class does but also does 
 *  more because it is a supermole class. It is able to give a perk to the player which is the 
 *  big difference between that class and the mole class. With polymorphism, both classes 
 *  have methods that are the same but do different things. When the get image method is called 
 *  from both classes, they give different images because they both have their own images based 
 *  on their respective classes. Both games utilize animation and collision detection. 
 *  When the mole hits the hammer, or the player hits the barrier, collision detection is used. 
 *  Animation is used throughout both games, through various keyframes and animation timers. 
 *  The file class is used when displaying high scores to the user. The file is first read in, 
 *  then a file writer outputs the edited file. ArrayLists are utilized when creating the choice 
 *  dialog, and sorting through the user's highscores. There is background music that spans the 
 *  length of the program being used and sounds when the moles, hammers, barriers,and  balls interact.
 *  

 */

package application;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;
import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class Main extends Application {
	private Scene scene;
	private AnimationTimer animation2,animation;
	private wall hitg;
	private shoot ballp;
	boolean up=false;
	Timeline clock;
	private int seconds=45;
	private int scores=50;
	private int bullets=30;
	private int speed=15;
	Label lblName = new Label();
	Label lblName2 = new Label();
	Label lblName3 = new Label();
	private Image imgBacks = new Image("file:game-background.png");
	Image imgBackmole = new Image("file:holes (1).png");
	private AudioClip hit;
	private AudioClip finished;
	private Media moleMusic;
	private MediaPlayer molePlayer;
	private AnimationTimer click;
	private KeyFrame key;
	private Timeline time;
	private KeyFrame noPoints;
	private Timeline lessPoints;
	private KeyFrame noTime;
	private Timeline lessTime;
	private KeyFrame more;
	private Timeline point;
	private KeyFrame freeze;
	private Timeline freezeTime;
	private KeyFrame limit;
	private Timeline limitTime;
	private int rndInt1;
	private int rndInt2;
	private int rndInt3;
	private int score;
	private Label labelScore;
	private Label labelTime;
	private Label frozen;
	private Label noTimes;
	private Label noPoint;
	private Label pointTime;
	private int count;
	private int froze;
	private int points;
	private int times;
	private int pointless;
	private GridPane root = new GridPane();
	public void start(Stage primaryStage) {
		try {

			//code to create madia player
			File file = new File("caravan.ogg.wav");
			moleMusic = new Media(file.toURI().toString());
			molePlayer = new MediaPlayer(moleMusic);

			//plays backgorund song until user exits
			molePlayer.setOnEndOfMedia(new Runnable() {
				public void run()
				{
					molePlayer.seek(Duration.ZERO);
				}
			});
			molePlayer.play();

			//set imagview and create image object for gridpane backgorund
			Image imgBack = new Image("file:backm.png");
			ImageView iviewBackground = new ImageView(imgBack);

			//set grid pane specifics
			root.setPadding(new Insets(10, 10, 10, 10));
			root.setHgap(30);
			root.setVgap(70);
			root.setAlignment(Pos.BASELINE_CENTER);		

			//set scene
			scene = new Scene(root, imgBack.getWidth(), imgBack.getHeight());


			//create images and imageviews for the buttons
			Image imghitm = new Image("file:hitormissm.jpg");
			ImageView ivhitm = new ImageView(imghitm);

			Image imgmolem = new Image("file:whackamolem.jpg");
			ImageView ivmolem = new ImageView(imgmolem);

			Image imgexitm = new Image("file:exitm.png");
			ImageView ivexit = new ImageView(imgexitm);


			//create buttoms
			Button molem = new Button();
			Button hitm = new Button();
			Button exitm = new Button();

			hitm.setGraphic(ivhitm);
			//if set on action resize scene to new stage and access method
			hitm.setOnAction(e-> {primaryStage.setWidth(imgBacks.getWidth());primaryStage.setHeight(imgBacks.getHeight());primaryStage.setX(0); try {
				hitmb();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}});
			//if set on action resize scene to new stage and access method
			molem.setOnAction(e-> {primaryStage.setWidth(imgBackmole.getWidth());primaryStage.setHeight(imgBackmole.getHeight());primaryStage.setX(200); molemb();});
			molem.setGraphic(ivmolem);
			exitm.setGraphic(ivexit);
			//access method
			exitm.setOnAction(e-> exit());



			//add backgorund to gridapne
			GridPane.setColumnSpan(iviewBackground, 3);
			GridPane.setRowSpan(iviewBackground, 3);
			GridPane.setHalignment(iviewBackground, HPos.CENTER);
			GridPane.setValignment(iviewBackground, VPos.BOTTOM);
			root.add(iviewBackground, 0, 0);


			//add buttons to gridapne
			GridPane.setColumnSpan(hitm, 1);
			GridPane.setHalignment(hitm, HPos.CENTER);
			GridPane.setValignment(hitm, VPos.CENTER);
			root.add(hitm, 2, 2);

			GridPane.setColumnSpan(molem, 1);
			GridPane.setHalignment(molem, HPos.LEFT);
			GridPane.setValignment(molem, VPos.CENTER);
			root.add(molem, 1, 2);

			GridPane.setColumnSpan(exitm, 2);
			GridPane.setHalignment(exitm, HPos.CENTER);
			GridPane.setValignment(exitm, VPos.BOTTOM);
			root.add(exitm, 1, 2);

			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}


	private void hitmb()throws IOException
	{




		//declare audioclip
		AudioClip goodjob= new AudioClip("file:soundg.mp3");

		//display a;=lert highlighting intro to game
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setContentText("Welcome to HIT OR MISS! The objective of this game is to hit the yellow barrier as many times as possible! You start off with 50 points, and every miss reduces your score by 10. You have 30 bullets, and every miss reduces them by one. There is a 45 second timer. The game ends when either of the three criteria reaches 0. To attempt to hit the barrier, hit the spacebar.\r\n"
				+ "\r\n"
				+ "GOOD LUCK HUNTING!\r\n"
				+ "");
		alert.setTitle("HIT OR MISS!");
		alert.showAndWait();

		//set backgorund of hit or miss
		Image imgBack = new Image("file:game-background.png");
		ImageView iviewBackground = new ImageView(imgBack);

		//set iimagview of pipe
		Image imgpipe = new Image("file:pipe.png");
		ImageView iviewpipe = new ImageView(imgpipe);


		//create labels diplaying ammo, timer,score
		Label lblName = new Label();
		lblName.setFont(Font.font("Britannic Bold", FontWeight.BOLD, FontPosture.REGULAR, 30));
		lblName.setText("Score:"+scores);
		lblName.setTextFill(Color.BLACK);
		lblName.setPrefSize(140, 50);
		lblName.setLayoutX(0);
		lblName.setLayoutY(0);

		Label lblName2 = new Label();
		lblName2.setFont(Font.font("Britannic Bold", FontWeight.BOLD, FontPosture.REGULAR, 30));
		lblName2.setText("Time:"+seconds);
		lblName2.setTextFill(Color.BLACK);
		lblName2.setPrefSize(140, 50);
		lblName2.setLayoutX(imgBack.getWidth()/2-lblName2.getWidth()/2-60);
		lblName2.setLayoutY(0);

		Label lblName3 = new Label();
		lblName3.setFont(Font.font("Britannic Bold", FontWeight.BOLD, FontPosture.REGULAR, 30));
		lblName3.setText("Ammo:"+bullets);
		lblName3.setTextFill(Color.BLACK);
		lblName3.setPrefSize(140, 50);
		lblName3.setLayoutX(imgBack.getWidth()-140);
		lblName3.setLayoutY(0);

		//create new pane
		Pane roots = new Pane();

		//create pointers that point towards each class
		hitg = new wall();
		ballp=new shoot();

		//set the scene to the new pane
		scene.setRoot(roots);

		roots.getChildren().add(iviewBackground);


		//set locaton of pipe to bottom middle
		iviewpipe.setX(imgBack.getWidth()/2-imgpipe.getWidth()/2);
		iviewpipe.setY(537);

		//set location of barrier and ball
		hitg.setLocation((int)(imgBack.getWidth()), 40);
		ballp.setLocation((int)(imgBack.getWidth()), (int)imgBack.getHeight());

		//add components to pane
		roots.getChildren().addAll(hitg.getImage(),iviewpipe,ballp.getImage(),lblName,lblName2,lblName3);

		//enter keyframe animatiin timer
		KeyFrame kf= new KeyFrame(Duration.millis(1000),new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent e) {
				//decrease seconds every minute and update label
				seconds--;
				lblName2.setText("Time:"+seconds);

				//if theese conditoosn are met game is over
				if (seconds==0||scores==0)
				{
					//remove compnets from pane
					roots.getChildren().remove(ballp.getImage());

					//stop aimation timers
					clock.stop();
					animation2.stop();
					animation.stop();

					//emnter platform.run later
					Platform.runLater(new Runnable() {
						public void run()
						{



							//outptut alert to user
							Alert alert = new Alert(AlertType.ERROR);
							alert.setGraphic(ballp.getImage());
							alert.setHeaderText(null);
							alert.setContentText("\nGAME OVER!\nYour score was: "+scores+"!");
							alert.setTitle("GAME OVER!");
							alert.showAndWait();

							//create choice dialog 
							ArrayList<String> choices = new ArrayList<String>();
							choices.add("A - View HighScores");
							choices.add("B - Exit");
							ChoiceDialog<String> dialog = new
									ChoiceDialog<String>(choices.get(0), choices);
							dialog.setTitle("GameEnd");
							dialog.setHeaderText("What would you like to do next");
							dialog.setContentText(null);
							Optional<String> result = dialog.showAndWait();

							if (result.isPresent())
							{
								String input = result.get().substring(0, 1);
								//if asks for highscore
								if(input.equals("A"))
								{
									//outptut alert to user
									Alert alert2 = new Alert(AlertType.ERROR);
									alert2.setGraphic(ballp.getImage());
									alert2.setHeaderText(null);
									alert2.setContentText("LOOK AT THE FILE CALLED HIGHSCORES.TXT.\n THIS FILE ORGANINZES SCORES IN ASCENDING ORDER");
									alert2.setTitle("Records");
									alert2.showAndWait();

									try
									{
										//declare file readers
										File textFile = new File("HIGHSCORES.txt");
										FileReader in = new FileReader(textFile);
										BufferedReader readFile = new BufferedReader(in);
										ArrayList<String> highscores= new ArrayList<String>();
										ArrayList<String> highscores2= new ArrayList<String>();

										String lineoftext;

										//enter while loop to add file contents to arrya list
										while((lineoftext = readFile.readLine()) != null)
										{
											highscores.add(lineoftext);

										}
										readFile.close();
										in.close();

										

										highscores.add(Integer.toString(scores));

										for(int i = 0; i < highscores.size()-1; i++)
										{
											int index = i;
											// Searching for the lowest index
											for (int j = i+1; j < highscores.size(); j++)
											{
												if (Integer.parseInt(highscores.get(j)) <Integer.parseInt( highscores.get(index)))
												{
													index = j;
												}
											}
											// Swap the elements
											String smallerNumber = highscores.get(index);

											highscores.set(index,  highscores.get(i));

											highscores.set(i, smallerNumber);

										}

										//create filewriter
										FileWriter out = new FileWriter (textFile);
										BufferedWriter writeFile = new BufferedWriter(out);



										//for loop to write scores
										for(int j=0;j<highscores.size();j++)
										{
											writeFile.write(highscores.get(j));
											writeFile.newLine();

										}
										writeFile.close();
										out.close();
									}
									catch(IOException e)
									{
										System.out.println("File does not exist or not found");
										System.err.println("FileNotFoundException: "+e.getMessage());
									}


									System.exit(0);

								}
								else
								{
									System.exit(0);
								}
							}

						}
					});
				}




			}
		});
		//create timeline and set cycle to indefinete
		clock= new Timeline(kf);
		clock.setCycleCount(Timeline.INDEFINITE);
		clock.play();

		//eneter animation timer to move ball
		animation2 = new AnimationTimer() {
			public void handle(long val) {


				if(scores==0)
				{
					roots.getChildren().remove(ballp.getImage());
					clock.stop();
					animation2.stop();
					animation.stop();
					Platform.runLater(new Runnable() {
						public void run()
						{



							//outptut alert to user
							Alert alert = new Alert(AlertType.ERROR);
							alert.setGraphic(ballp.getImage());
							alert.setHeaderText(null);
							alert.setContentText("\nGAME OVER!\nYour score was: "+scores+"!");
							alert.setTitle("GAME OVER!");


							alert.showAndWait();

							ArrayList<String> choices = new ArrayList<String>();
							choices.add("A - View HighScores");
							choices.add("B - Exit");
							ChoiceDialog<String> dialog = new
									ChoiceDialog<String>(choices.get(0), choices);
							dialog.setTitle("GameEnd");
							dialog.setHeaderText("What would you like to do next");
							dialog.setContentText(null);
							Optional<String> result = dialog.showAndWait();

							if (result.isPresent())
							{
								String input = result.get().substring(0, 1);
								if(input.equals("A"))
								{
									//outptut alert to user
									Alert alert2 = new Alert(AlertType.ERROR);
									alert2.setGraphic(ballp.getImage());
									alert2.setHeaderText(null);
									alert2.setContentText("LOOK AT THE FILE CALLED HIGHSCORES.TXT.\n THIS FILE ORGANINZES SCORES IN ASCENDING ORDER");
									alert2.setTitle("Records");
									alert2.showAndWait();

									try
									{
										//declare file readers
										File textFile = new File("HIGHSCORES.txt");
										FileReader in = new FileReader(textFile);
										BufferedReader readFile = new BufferedReader(in);
										ArrayList<String> highscores= new ArrayList<String>();
										ArrayList<String> highscores2= new ArrayList<String>();

										String lineoftext;

										//enter while loop to add file contents to arrya list
										while((lineoftext = readFile.readLine()) != null)
										{
											highscores.add(lineoftext);

										}
										readFile.close();
										in.close();

										

										highscores.add(Integer.toString(scores));

										for(int i = 0; i < highscores.size()-1; i++)
										{
											int index = i;
											// Searching for the lowest index
											for (int j = i+1; j < highscores.size(); j++)
											{
												if (Integer.parseInt(highscores.get(j)) <Integer.parseInt( highscores.get(index)))
												{
													index = j;
												}
											}
											// Swap the elements
											String smallerNumber = highscores.get(index);

											highscores.set(index,  highscores.get(i));

											highscores.set(i, smallerNumber);

										}

										//create filewriter
										FileWriter out = new FileWriter (textFile);
										BufferedWriter writeFile = new BufferedWriter(out);



										//for loop to write scores
										for(int j=0;j<highscores.size();j++)
										{
											writeFile.write(highscores.get(j));
											writeFile.newLine();

										}
										writeFile.close();
										out.close();
									}
									catch(IOException e)
									{
										System.out.println("File does not exist or not found");
										System.err.println("FileNotFoundException: "+e.getMessage());
									}


									System.exit(0);
								}
								else
								{
									System.exit(0);
								}
							}

						}
					});
				}

				//move based on the speed variable assigned
				hitg.moveleft(speed);

				if(hitg.getX()<=0)
				{
					//increase speed as time winds down
					speed=-15-(30-seconds)/2-10;


				}
				else if(hitg.getX()+hitg.getWidth()>imgBack.getWidth())
				{
					//increase speed as time winds down
					speed=15+(30-seconds)/2+10;
				}


			}};

			animation2.start();

			animation = new AnimationTimer() {
				public void handle(long val) {

					//access move emthods and set how much to move

					//if game over
					if(scores==0||bullets==0)
					{
						roots.getChildren().remove(ballp.getImage());
						clock.stop();
						animation2.stop();
						animation.stop();
						Platform.runLater(new Runnable() {
							public void run()
							{



								//outptut alert to user
								Alert alert = new Alert(AlertType.ERROR);
								alert.setGraphic(ballp.getImage());
								alert.setHeaderText(null);
								alert.setContentText("\nGAME OVER!\nYour score was: "+scores+"!");
								alert.setTitle("GAME OVER!");


								alert.showAndWait();

								ArrayList<String> choices = new ArrayList<String>();

								choices.add("A - View HighScores");
								choices.add("B - Exit");
								ChoiceDialog<String> dialog = new
										ChoiceDialog<String>(choices.get(0), choices);
								dialog.setTitle("GameEnd");
								dialog.setHeaderText("What would you like to do next");
								dialog.setContentText(null);
								Optional<String> result = dialog.showAndWait();

								if (result.isPresent())
								{
									String input = result.get().substring(0, 1);

									if(input.equals("A"))
									{
										//outptut alert to user
										Alert alert2 = new Alert(AlertType.ERROR);
										alert2.setGraphic(ballp.getImage());
										alert2.setHeaderText(null);
										alert2.setContentText("LOOK AT THE FILE CALLED HIGHSCORES.TXT.\n THIS FILE ORGANINZES SCORES IN ASCENDING ORDER");
										alert2.setTitle("Records");
										alert2.showAndWait();

										try
										{
											//declare file readers
											File textFile = new File("HIGHSCORES.txt");
											FileReader in = new FileReader(textFile);
											BufferedReader readFile = new BufferedReader(in);
											ArrayList<String> highscores= new ArrayList<String>();
											ArrayList<String> highscores2= new ArrayList<String>();

											String lineoftext;

											//enter while loop to add file contents to arrya list
											while((lineoftext = readFile.readLine()) != null)
											{
												highscores.add(lineoftext);

											}
											readFile.close();
											in.close();

											

											highscores.add(Integer.toString(scores));

											for(int i = 0; i < highscores.size()-1; i++)
											{
												int index = i;
												// Searching for the lowest index
												for (int j = i+1; j < highscores.size(); j++)
												{
													if (Integer.parseInt(highscores.get(j)) <Integer.parseInt( highscores.get(index)))
													{
														index = j;
													}
												}
												// Swap the elements
												String smallerNumber = highscores.get(index);

												highscores.set(index,  highscores.get(i));

												highscores.set(i, smallerNumber);

											}

											//create filewriter
											FileWriter out = new FileWriter (textFile);
											BufferedWriter writeFile = new BufferedWriter(out);



											//for loop to write scores
											for(int j=0;j<highscores.size();j++)
											{
												writeFile.write(highscores.get(j));
												writeFile.newLine();

											}
											writeFile.close();
											out.close();
										}
										catch(IOException e)
										{
											System.out.println("File does not exist or not found");
											System.err.println("FileNotFoundException: "+e.getMessage());
										}


										System.exit(0);
									}
									else
									{
										System.exit(0);
									}
								}

							}
						});
					}
					//move the ball
					ballp.move(40,up);

					//if ball leaves from top then it counts as miss and reduce score and bullets and update labels
					if(ballp.getY()+ballp.getHeight()<0)
					{
						scores-=10;


						bullets--;

						//update labels
						lblName3.setText("Ammo:"+bullets);
						lblName.setText("Score:"+scores);

						//set new location
						ballp.setY((int)imgBacks.getHeight());
						up=false;

					}

					//if colliso =n occurs increase score
					if((ballp.getImage().getBoundsInParent()).intersects(hitg.getImage().getBoundsInParent()))
					{

						//play audio clip
						goodjob.play();

						//update label
						lblName.setText("Time:"+seconds);
						//make ball dissapaer
						ballp.move(-10000,up);
						//incrwease score
						scores+=10;


						lblName.setText("Score:"+scores);

						//set location and update image
						ballp.setY((int)imgBacks.getHeight());
						ballp.getImage();

						//fix boolean variables
						up=false;



					}


					//get image
					ballp.getImage();			

				}

			};
			animation.start();



			//for smooth animation use booolean values for pressed and realsed depending on the dierction
			scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
				public void handle(KeyEvent e) {

					if(e.getCode()==KeyCode.SPACE)
					{

						up=true;

					}

					ballp.getImage();
				}
			});

			scene.setOnKeyReleased(new EventHandler<KeyEvent>() {
				public void handle(KeyEvent e) {

					if(e.getCode()==KeyCode.SPACE)
					{
						up=true;
					}

					ballp.getImage();
				}
			});	



	}







	private void molemb()
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setContentText("Welcome to Whack A Mole!\nThere are 9 holes where moles can randomly spawn and your job is to whack as many as you can before the time runs out. Watch out for the super mole with the crown as he can reward you with good or bad perks upon killing him. You can have time frozen to whack to your hearts desire or gain extra points but can also lose points or time, so be careful as once the timer ends, thats it. Good luck my friend");
		alert.setTitle("WHACK A MOLE");
		alert.showAndWait();

		Pane rootyy = new Pane();

		//Background Image
		Image imgBack = new Image("file:holes (1).png");
		ImageView iViewBack = new ImageView(imgBack);

		//2D array of the regular and super moles
		moles[][] moles = new moles [3][3];
		SuperMole[][] superMoles = new SuperMole [3][3];

		//Image of the hammer
		Image hammer = new Image("file:hammer.png");
		ImageView viewHammer = new ImageView(hammer);

		scene.setRoot(rootyy);

		//Code to make the hammer follow the cursor
		scene.setOnMouseMoved(new EventHandler<MouseEvent>()
		{
			public void handle(MouseEvent e) {
				viewHammer.setX(e.getX() - hammer.getWidth() / 2);
				viewHammer.setY(e.getY() - hammer.getHeight() / 2);
			}
		});

		//random variable to allow to make random numbers
		Random rnd = new Random();

		//Sound effects for hitting and when the game ends
		hit = new AudioClip("file:slap.mp3");

		finished = new AudioClip("file:ending.mp3");



		//Variables used for when powerups are active to use as a counter as to when it ends
		points = 0;

		froze = 0;

		count = 30;

		times = 0;

		pointless = 0;

		//Keyframe for ability to get more points
		more = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent e)
			{
				//The points counter will go down, the score will increase and a label will inform the player that they are getting extra points
				points--;
				score = score + 5;
				labelScore.setText("Score: " + score);
				pointTime.setText("Extra Points " + points);
				rootyy.getChildren().remove(pointTime);
				rootyy.getChildren().add(pointTime);

				if(points < 0)
				{
					//onces the ability is done, the label is removed and the keyframe is stopped
					rootyy.getChildren().remove(pointTime);
					point.stop();
				}
			}
		});

		//Keyframe for ability to lose time
		noTime = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent e)
			{				
				//the time counter will go down and a label will inform the player that they have lost time
				times--;
				rootyy.getChildren().remove(noTimes);
				rootyy.getChildren().add(noTimes);

				if(times < 0)
				{
					//After a second, the label will disappear and the keyframe is stopped
					rootyy.getChildren().remove(noTimes);
					lessTime.stop();
				}
			}
		});

		//Keyframe for ability to lose points
		noPoints = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent e)
			{			
				//the pointless counter will go down and a label will inform the player that they have lost points
				pointless--;
				rootyy.getChildren().remove(noPoint);
				rootyy.getChildren().add(noPoint);

				if(pointless < 0)
				{
					//after a second, the label will be removed and the keyframe is stopped
					rootyy.getChildren().remove(noPoint);
					lessPoints.stop();
				}
			}
		});

		//Keyframe for ability to freeze time
		freeze = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>()
		{
			//All the moles present in the screen at the time are set to be not hit so the player can spam hit the moles
			public void handle(ActionEvent e)
			{
				moles[0][0].notHit();
				moles[0][1].notHit();
				moles[0][2].notHit();
				moles[1][0].notHit();
				moles[1][1].notHit();
				moles[1][2].notHit();
				moles[2][0].notHit();
				moles[2][1].notHit();
				moles[2][2].notHit();

				superMoles[0][0].notHit();
				superMoles[0][1].notHit();
				superMoles[0][2].notHit();
				superMoles[1][0].notHit();
				superMoles[1][1].notHit();
				superMoles[1][2].notHit();
				superMoles[2][0].notHit();
				superMoles[2][1].notHit();
				superMoles[2][2].notHit();

				//the froze counter will go down and the keyframes for the game will stop to "freeze" the game with a label informing the player 
				froze--;
				time.stop();
				limitTime.stop();
				frozen.setText("Freeze Activated " + froze);
				rootyy.getChildren().remove(frozen);
				rootyy.getChildren().add(frozen);

				if(froze < 1)
				{
					//once the counter is zero, the keyframes are no longer frozen and the label is removed
					freezeTime.stop();
					time.playFromStart();
					limitTime.play();
					rootyy.getChildren().remove(frozen);
				}
			}
		});

		//Keyframe for the game to make a time limit
		limit = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent e)
			{
				//The count variable goes down with a label informing the player of the time left
				count--;
				labelTime.setText("Time Left: " + count);
				if(count == 0)
				{
					//Once time is up, the keyframes are stopped and an alert shows up telling the user of their score
					finished.play();
					molePlayer.stop();
					limitTime.stop();
					time.stop();
					freezeTime.stop();
					Platform.runLater(new Runnable() {
						public void run()
						{
							Alert alert = new Alert(AlertType.ERROR);
							alert.setHeaderText(null);
							labelTime.setText("Time Left: 0");
							alert.setContentText("\nGAME OVER!\nYour Score was: " + score);
							alert.setTitle("Game Over");
							alert.showAndWait();
							System.exit(0);


						}
					});
				}
			}
		});

		//Initializing every element in each 2D array 
		for (int row = 0; row < 3; row++)
		{
			for (int col = 0; col < 3; col++)
			{
				moles[row][col] = new moles();
				superMoles[row][col] = new SuperMole();

				if(row == 0)
				{
					moles[row][col].setYHappy(0);
					superMoles[row][col].setYHappy(0);
				}
				else if(row == 1)
				{
					moles[row][col].setYHappy(210);
					superMoles[row][col].setYHappy(210);
				}
				else if(row == 2)
				{
					moles[row][col].setYHappy(430);
					superMoles[row][col].setYHappy(430);
				}

				if(col == 0)
				{
					moles[row][col].setXHappy(100);
					superMoles[row][col].setXHappy(100);
				}
				else if(col == 1)
				{
					moles[row][col].setXHappy(315);
					superMoles[row][col].setXHappy(315);
				}
				else if(col == 2)
				{
					moles[row][col].setXHappy(530);
					superMoles[row][col].setXHappy(530);
				}
			}	
		}

		//Method for when the mouse is clicked and to check if it is clicked over a mole or not
		scene.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent e)
			{
				hit.play();

				//Depending on which spot the mouse is clicked at, this checks if it is above a hole and to check if there is a mole present at the time
				//If there is a special mole that is clicked, a random int variable is made to decide which perk is given to the player
				if(e.getX() >= 125 && e.getX() <= 125 + 65.0 && e.getY() >= 25 && e.getY() <= 25 + 60)
				{	
					if(rndInt1 == 1 || rndInt2 == 1 )
					{
						if(moles[0][0].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[0][0].hit();
						rootyy.getChildren().remove(moles[0][0].getImage());
						rootyy.getChildren().add(moles[0][0].getImage());
					}
					if(rndInt3 == 1)
					{
						if(superMoles[0][0].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[0][0].hit();
						rootyy.getChildren().remove(superMoles[0][0].getImage());
						rootyy.getChildren().add(superMoles[0][0].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 340 && e.getX() <= 340 + 65.0 && e.getY() >= 25 && e.getY() <= 25 + 60)
				{
					if(rndInt1 == 2 || rndInt2 == 2 )
					{
						if(moles[0][1].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[0][1].hit();
						rootyy.getChildren().remove(moles[0][1].getImage());
						rootyy.getChildren().add(moles[0][1].getImage());
					}
					if(rndInt3 == 2)
					{
						if(superMoles[0][1].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[0][1].hit();
						rootyy.getChildren().remove(superMoles[0][1].getImage());
						rootyy.getChildren().add(superMoles[0][1].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}

					}
				}
				else if(e.getX() >= 555 && e.getX() <= 555 + 65.0 && e.getY() >= 25 && e.getY() <= 25 + 60)
				{
					if(rndInt1 == 3 || rndInt2 == 3 )
					{
						if(moles[0][2].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[0][2].hit();
						rootyy.getChildren().remove(moles[0][2].getImage());
						rootyy.getChildren().add(moles[0][2].getImage());
					}
					if(rndInt3 == 3)
					{
						if(superMoles[0][2].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[0][2].hit();
						rootyy.getChildren().remove(superMoles[0][2].getImage());
						rootyy.getChildren().add(superMoles[0][2].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 125 && e.getX() <= 125 + 65.0 && e.getY() >= 235 && e.getY() <= 235 + 60)
				{
					if(rndInt1 == 4 || rndInt2 == 4)
					{
						if(moles[1][0].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[1][0].hit();
						rootyy.getChildren().remove(moles[1][0].getImage());
						rootyy.getChildren().add(moles[1][0].getImage());
					}
					if(rndInt3 == 4)
					{
						if(superMoles[1][0].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[1][0].hit();
						rootyy.getChildren().remove(superMoles[1][0].getImage());
						rootyy.getChildren().add(superMoles[1][0].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 340 && e.getX() <= 340 + 65.0 && e.getY() >= 235 && e.getY() <= 235 + 60)
				{
					if(rndInt1 == 5 || rndInt2 == 5)
					{
						if(moles[1][1].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[1][1].hit();
						rootyy.getChildren().remove(moles[1][1].getImage());
						rootyy.getChildren().add(moles[1][1].getImage());
					}
					if(rndInt3 == 5)
					{
						if(superMoles[1][1].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[1][1].hit();
						rootyy.getChildren().remove(superMoles[1][1].getImage());
						rootyy.getChildren().add(superMoles[1][1].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 555 && e.getX() <= 555 + 65.0 && e.getY() >= 235 && e.getY() <= 235 + 60)
				{
					if(rndInt1 == 6 || rndInt2 == 6)
					{

						if(moles[1][2].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}
						moles[1][2].hit();
						rootyy.getChildren().remove(moles[1][2].getImage());
						rootyy.getChildren().add(moles[1][2].getImage());
					}
					if(rndInt3 == 6)
					{
						if(superMoles[1][2].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[1][2].hit();
						rootyy.getChildren().remove(superMoles[1][2].getImage());
						rootyy.getChildren().add(superMoles[1][2].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 125 && e.getX() <= 125 + 65.0 && e.getY() >= 455 && e.getY() <= 455 + 60)
				{
					if(rndInt1 == 7 || rndInt2 == 7)
					{
						if(moles[2][0].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[2][0].hit();
						rootyy.getChildren().remove(moles[2][0].getImage());
						rootyy.getChildren().add(moles[2][0].getImage());
					}
					if(rndInt3 == 7)
					{
						if(superMoles[2][0].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[2][0].hit();
						rootyy.getChildren().remove(superMoles[2][0].getImage());
						rootyy.getChildren().add(superMoles[2][0].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 340 && e.getX() <= 340 + 65.0 && e.getY() >= 455 && e.getY() <= 455 + 60)
				{
					if(rndInt1 == 8 || rndInt2 == 8 )
					{
						if(moles[2][1].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[2][1].hit();
						rootyy.getChildren().remove(moles[2][1].getImage());
						rootyy.getChildren().add(moles[2][1].getImage());
					}
					if(rndInt3 == 8)
					{
						if(superMoles[2][1].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[2][1].hit();
						rootyy.getChildren().remove(superMoles[2][1].getImage());
						rootyy.getChildren().add(superMoles[2][1].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
				else if(e.getX() >= 555 && e.getX() <= 555 + 65.0 && e.getY() >= 455 && e.getY() <= 455 + 60)
				{
					if(rndInt1 == 9 || rndInt2 == 9)
					{
						if(moles[2][2].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						moles[2][2].hit();
						rootyy.getChildren().remove(moles[2][2].getImage());
						rootyy.getChildren().add(moles[2][2].getImage());
					}
					if(rndInt3 == 9)
					{
						if(superMoles[2][2].beenHit() == false)
						{
							score = score + 1;
							labelScore.setText("Score: " + score);
						}
						else
						{

						}

						superMoles[2][2].hit();
						rootyy.getChildren().remove(superMoles[2][2].getImage());
						rootyy.getChildren().add(superMoles[2][2].getImage());

						int power = rnd.nextInt(3) + 1;

						if(power == 1)
						{
							if(freezeTime.getStatus() == Animation.Status.RUNNING)
							{

							}
							else
							{
								froze = 6;
								freezeTime.play();
							}
						}
						else if(power == 2)
						{
							points = 5;
							point.play();
						}
						else if(power == 3)
						{
							score = score - 5;
							pointless = 1;
							lessPoints.play();
						}
						else if(power == 4)
						{
							count = count - 5;
							times = 1;
							lessTime.play();
						}
					}
				}
			}
		});

		//Keyframe to make moles spawn in different spots every 2 seconds
		key = new KeyFrame(Duration.millis(2000), new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent e)
			{	
				//All moles are removed at the start
				rootyy.getChildren().removeAll(moles[0][0].getImage(),moles[0][1].getImage(),moles[0][2].getImage(),moles[1][0].getImage(),moles[1][1].getImage(),moles[1][2].getImage(),moles[2][0].getImage(),moles[2][1].getImage(),moles[2][2].getImage());
				rootyy.getChildren().removeAll(superMoles[0][0].getImage(),superMoles[0][1].getImage(),superMoles[0][2].getImage(),superMoles[1][0].getImage(),superMoles[1][1].getImage(),superMoles[1][2].getImage(),superMoles[2][0].getImage(),superMoles[2][1].getImage(),superMoles[2][2].getImage());

				//All moles are rendered as not hit
				moles[0][0].notHit();
				moles[0][1].notHit();
				moles[0][2].notHit();
				moles[1][0].notHit();
				moles[1][1].notHit();
				moles[1][2].notHit();
				moles[2][0].notHit();
				moles[2][1].notHit();
				moles[2][2].notHit();

				superMoles[0][0].notHit();
				superMoles[0][1].notHit();
				superMoles[0][2].notHit();
				superMoles[1][0].notHit();
				superMoles[1][1].notHit();
				superMoles[1][2].notHit();
				superMoles[2][0].notHit();
				superMoles[2][1].notHit();
				superMoles[2][2].notHit();

				rndInt1 = rnd.nextInt(8)+ 1;
				rndInt2 = rnd.nextInt(8)+ 1;
				rndInt3 = rnd.nextInt(8)+ 1;


				//The random int variables are made and depending on what number it is, they are given a spot in the game for one of the 9 holes
				if(rndInt1 == 1)
				{
					rootyy.getChildren().remove(moles[0][0].getImage());
					rootyy.getChildren().add(moles[0][0].getImage());
				}
				else if(rndInt1 == 2)
				{
					rootyy.getChildren().remove(moles[0][2].getImage());
					rootyy.getChildren().add(moles[0][1].getImage());
				}
				else if(rndInt1 == 3)
				{
					rootyy.getChildren().remove(moles[0][2].getImage());
					rootyy.getChildren().add(moles[0][2].getImage());
				}
				else if(rndInt1 == 4)
				{
					rootyy.getChildren().remove(moles[1][0].getImage());
					rootyy.getChildren().add(moles[1][0].getImage());
				}
				else if(rndInt1 == 5)
				{
					rootyy.getChildren().remove(moles[1][1].getImage());
					rootyy.getChildren().add(moles[1][1].getImage());
				}
				else if(rndInt1 == 6)
				{
					rootyy.getChildren().remove(moles[1][2].getImage());
					rootyy.getChildren().add(moles[1][2].getImage());
				}
				else if(rndInt1 == 7)
				{
					rootyy.getChildren().remove(moles[2][0].getImage());
					rootyy.getChildren().add(moles[2][0].getImage());
				}
				else if(rndInt1 == 8)
				{
					rootyy.getChildren().remove(moles[2][1].getImage());
					rootyy.getChildren().add(moles[2][1].getImage());
				}
				else if(rndInt1 == 9)
				{
					rootyy.getChildren().remove(moles[2][2].getImage());
					rootyy.getChildren().add(moles[2][2].getImage());
				}

				if(rndInt2 == 1)
				{
					rootyy.getChildren().remove(moles[0][0].getImage());
					rootyy.getChildren().add(moles[0][0].getImage());
				}
				else if(rndInt2 == 2)
				{
					rootyy.getChildren().remove(moles[0][1].getImage());
					rootyy.getChildren().add(moles[0][1].getImage());
				}
				else if(rndInt2 == 3)
				{
					rootyy.getChildren().remove(moles[0][2].getImage());
					rootyy.getChildren().add(moles[0][2].getImage());
				}
				else if(rndInt2 == 4)
				{
					rootyy.getChildren().remove(moles[1][0].getImage());
					rootyy.getChildren().add(moles[1][0].getImage());
				}
				else if(rndInt2 == 5)
				{
					rootyy.getChildren().remove(moles[1][1].getImage());
					rootyy.getChildren().add(moles[1][1].getImage());
				}
				else if(rndInt2 == 6)
				{
					rootyy.getChildren().remove(moles[1][2].getImage());
					rootyy.getChildren().add(moles[1][2].getImage());
				}
				else if(rndInt2 == 7)
				{
					rootyy.getChildren().remove(moles[2][0].getImage());
					rootyy.getChildren().add(moles[2][0].getImage());
				}
				else if(rndInt2 == 8)
				{
					rootyy.getChildren().remove(moles[2][1].getImage());
					rootyy.getChildren().add(moles[2][1].getImage());
				}
				else if(rndInt2 == 9)
				{
					rootyy.getChildren().remove(moles[2][2].getImage());
					rootyy.getChildren().add(moles[2][2].getImage());
				}

				if(rndInt3 == 1)
				{
					rootyy.getChildren().remove(superMoles[0][0].getImage());
					rootyy.getChildren().add(superMoles[0][0].getImage());
				}
				else if(rndInt3 == 2)
				{
					rootyy.getChildren().remove(superMoles[0][1].getImage());
					rootyy.getChildren().add(superMoles[0][1].getImage());
				}
				else if(rndInt3 == 3)
				{
					rootyy.getChildren().remove(superMoles[0][2].getImage());
					rootyy.getChildren().add(superMoles[0][2].getImage());
				}
				else if(rndInt3 == 4)
				{
					rootyy.getChildren().remove(superMoles[1][0].getImage());
					rootyy.getChildren().add(superMoles[1][0].getImage());
				}
				else if(rndInt3 == 5)
				{
					rootyy.getChildren().remove(superMoles[1][1].getImage());
					rootyy.getChildren().add(superMoles[1][1].getImage());
				}
				else if(rndInt3 == 6)
				{
					rootyy.getChildren().remove(superMoles[1][2].getImage());
					rootyy.getChildren().add(superMoles[1][2].getImage());
				}
				else if(rndInt3 == 7)
				{
					rootyy.getChildren().remove(superMoles[2][0].getImage());
					rootyy.getChildren().add(superMoles[2][0].getImage());
				}
				else if(rndInt3 == 8)
				{
					rootyy.getChildren().remove(superMoles[2][1].getImage());
					rootyy.getChildren().add(superMoles[2][1].getImage());
				}
				else if(rndInt3 == 9)
				{
					rootyy.getChildren().remove(superMoles[2][2].getImage());
					rootyy.getChildren().add(superMoles[2][2].getImage());
				}	

			}
		});

		//playing the keyframes for each of the abilities
		time = new Timeline(key);
		time.setCycleCount(Timeline.INDEFINITE);
		time.play();

		limitTime = new Timeline(limit);
		limitTime.setCycleCount(Timeline.INDEFINITE);
		limitTime.play();

		freezeTime = new Timeline(freeze);
		freezeTime.setCycleCount(Timeline.INDEFINITE);

		lessTime = new Timeline(noTime);
		lessTime.setCycleCount(Timeline.INDEFINITE);

		lessPoints = new Timeline(noPoints);
		lessPoints.setCycleCount(Timeline.INDEFINITE);

		point = new Timeline(more);
		point.setCycleCount(Timeline.INDEFINITE);

		//Making the score 0 for the start of the game
		score = 0;

		//Making the font
		Font font = Font.loadFont("file:JustMyType-KePl.ttf",25);

		//Label for the score
		labelScore = new Label();
		labelScore.setText("Score: " + score);
		labelScore.setPrefSize(150, 50);
		labelScore.setFont(font);
		labelScore.setAlignment(Pos.CENTER);
		labelScore.setTextFill(Color.WHITE);
		labelScore.setLayoutX(625);
		labelScore.setLayoutY(0);

		//Label to display that time is frozen
		frozen = new Label();
		frozen.setText("Freeze Activated " + froze);
		frozen.setPrefSize(150, 50);
		frozen.setFont(font);
		frozen.setAlignment(Pos.CENTER);
		frozen.setTextFill(Color.WHITE);
		frozen.setLayoutX(310);
		frozen.setLayoutY(0);

		//Label to display that there is less time now
		noTimes = new Label();
		noTimes.setText("Less Time");
		noTimes.setPrefSize(150, 50);
		noTimes.setFont(font);
		noTimes.setAlignment(Pos.CENTER);
		noTimes.setTextFill(Color.WHITE);
		noTimes.setLayoutX(310);
		noTimes.setLayoutY(0);

		//Label to display that there is less points now
		noPoint = new Label();
		noPoint.setText("Less Points");
		noPoint.setPrefSize(150, 50);
		noPoint.setFont(font);
		noPoint.setAlignment(Pos.CENTER);
		noPoint.setTextFill(Color.WHITE);
		noPoint.setLayoutX(310);
		noPoint.setLayoutY(0);

		//Label to display that there are more points now
		pointTime = new Label();
		pointTime.setText("Extra Points:" + points);
		pointTime.setPrefSize(150, 50);
		pointTime.setFont(font);
		pointTime.setAlignment(Pos.CENTER);
		pointTime.setTextFill(Color.WHITE);
		pointTime.setLayoutX(310);
		pointTime.setLayoutY(0);

		//Label to display the amount of time left
		labelTime = new Label();
		labelTime.setText("Time Left: " + count);
		labelTime.setPrefSize(150, 50);
		labelTime.setFont(font);
		labelTime.setAlignment(Pos.CENTER);
		labelTime.setTextFill(Color.WHITE);
		labelTime.setLayoutX(-10);
		labelTime.setLayoutY(0);

		//Code to add the background, hammer, the score and time label
		rootyy.getChildren().addAll(iViewBack,viewHammer,labelScore,labelTime);



	}
	private void exit()
	{
		System.exit(0);
	}
	public static void main(String[] args) {
		launch(args);
	}
}