package application;

import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

public class moles {

	//Variables
	private Image imgMoleHappy,imgMoleSad;
	private ImageView iViewMole;
	private int xPos,yPos;
	private boolean hit;
	private double width,height;

	//Constructor
	public moles()
	{
		imgMoleHappy = new Image("file:moleHappy1.png");
		imgMoleSad = new Image("file:moleSad1.png");
		iViewMole= new ImageView(imgMoleHappy);

		width = imgMoleHappy.getWidth();
		height = imgMoleHappy.getHeight();

		hit = false;

	}

	//Returns the width
	public double getWidth()
	{
		return width;
	}

	//Returns the Height
	public double getHeight()
	{
		return height;
	}

	//Sets the x position of the mole
	public void setXHappy(int x)
	{
		xPos = x;
		iViewMole.setX(xPos);
	}

	//Set the y position for the player
	public void setYHappy(int y)
	{
		yPos = y;
		iViewMole.setY(yPos);
	}

	//Returns the x variable
	public int getX()
	{
		return xPos;
	}

	//returns the y variable
	public int getY()
	{
		return yPos;
	}

	//Returns the image depending on if it is hit or not
	public ImageView getImage()
	{
		if(hit == true)
		{
			iViewMole.setImage(imgMoleSad);
		}
		else if(hit == false)
		{
			iViewMole.setImage(imgMoleHappy);
		}
		return iViewMole;
	}

	//Makes the hit boolean true to indicate the mole has been clicked
	public void hit()
	{
		hit = true;
	}

	//Keeps the hit boolean false to indicate the mole has not been clicked
	public void notHit()
	{
		hit = false;
	}

	//The boolean variable is returned to use in if statements for checking if the mole has been clicked on or not
	public boolean beenHit()
	{
		return hit;
	}
}