package application;

import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class wall {
	//variabels
	private Image wall; 
	private ImageView iviewwall;
	private int xPos, yPos, width, height;
	private Random rand;


	//contsurcor
	wall()
	{


		xPos =0; 
		yPos=0;
		wall = new Image("file:wall.png");
		//set imageview
		iviewwall = new ImageView(wall);
		//get width
		width = (int) wall.getWidth();
		height = (int) wall.getHeight();


	}
	//methods
	public ImageView getImage()
	{
		//set image
		iviewwall.setImage(wall); 
		return iviewwall;
	}
	public void setX(int x)
	{
		xPos=x;
	}
	public void setY(int y)
	{
		yPos=y;
	}
	public int getX()
	{
		return xPos;
	}
	public int getY()
	{
		return yPos;
	}
	public int getHeight()
	{
		return height;	
	}
	public int getWidth()
	{
		return width;
	}
	public void moveleft(int pixels)
	{
		//subtract pixels to make it go from east to wwest
		xPos-=pixels;
		iviewwall.setX(xPos);
	}
	public void moveright(int pixels)
	{
		//addd to move right
		xPos+=pixels;
		iviewwall.setX(xPos);
	}
	public void setLocation(int frameWidth,int frameHeight)
	{
		//set location to the end of the pane
		xPos=(int) ((int)frameWidth/2-wall.getWidth()/2);
		yPos=(80);
		iviewwall.setX(xPos);
		iviewwall.setY(yPos);
	}





}

