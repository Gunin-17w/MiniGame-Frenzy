package application;

import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class shoot {
	//variabels
	private Image ball; 
	private ImageView iviewball;
	private int xPos, yPos, width, height;
	private Random rand;


	//contsurcor
	shoot()
	{


		xPos =0; 
		yPos=0;
		//set image object
		ball = new Image("file:ball.png");
		//set imageview
		iviewball = new ImageView(ball);

		width = (int) ball.getWidth();
		height = (int) ball.getHeight();


	}
	//methods
	public ImageView getImage()
	{
		//set image
		iviewball.setImage(ball); 
		return iviewball;
	}
	public void setX(int x)
	{
		xPos=x;
	}
	public void setY(int y)
	{
		yPos=y;
	}
	public int getX()
	{
		return xPos;
	}
	public int getY()
	{
		return yPos;
	}
	public int getHeight()
	{
		return height;	
	}
	public int getWidth()
	{
		return width;
	}
	public void move(int pixels, boolean up)
	{
		if(up==true)
		{
			//if true move ball
			yPos-=pixels;
			iviewball.setY(yPos);
		}
	}

	public void setLocation(int frameWidth,int frameHeight)
	{
		//set location to the end of the pane
		xPos=(int) ((int)frameWidth/2-ball.getWidth()/2);
		yPos=(frameHeight);
		iviewball.setX(xPos);
		iviewball.setY(yPos);
	}





}

