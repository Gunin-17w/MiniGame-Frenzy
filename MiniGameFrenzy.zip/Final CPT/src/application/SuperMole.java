package application;

import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

//Inheritence
public class SuperMole extends moles{

	private Image imgMoleHappy,imgMoleSad;
	private ImageView iViewMole;
	private int xPos,yPos;
	private boolean hit;
	private double width,height;

	//Constructor
	public SuperMole()
	{
		imgMoleHappy = new Image("file:superMole.png");
		imgMoleSad = new Image("file:superMoleSad.png");
		iViewMole= new ImageView(imgMoleHappy);

		width = imgMoleHappy.getWidth();
		height = imgMoleHappy.getHeight();

		hit = false;

	}

	//Sets the x position
	public void setXHappy(int x)
	{
		xPos = x;
		iViewMole.setX(xPos);
	}

	//Sets the y position
	public void setYHappy(int y)
	{
		yPos = y;
		iViewMole.setY(yPos);
	}


	//Returns the image depending on if the mole was clicked on or not
	public ImageView getImage()
	{
		imgMoleHappy = new Image("file:superMole.png");
		imgMoleSad = new Image("file:superMoleSad.png");
		if(hit == true)
		{
			iViewMole.setImage(imgMoleSad);
		}
		else if(hit == false)
		{
			iViewMole.setImage(imgMoleHappy);
		}
		return iViewMole;
	}

	//Makes the hit boolean true to indicate the mole has been clicked
	public void hit()
	{
		hit = true;
	}

	//Keeps the hit boolean false to indicate the mole has not been clicked
	public void notHit()
	{
		hit = false;
	}

	//The boolean variable is returned to use in if statements for checking if the mole has been clicked on or not
	public boolean beenHit()
	{
		return hit;
	}
}